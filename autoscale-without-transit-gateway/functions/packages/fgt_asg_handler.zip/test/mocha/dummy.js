'use strict';

describe('Dummy test', function() {
    describe('#void', function() {});
});
