'use strict';

var assert = require('assert');
describe('Dummy test', function() {
    describe('#void', function() {
        assert.equal(1, 1);
    });
});
